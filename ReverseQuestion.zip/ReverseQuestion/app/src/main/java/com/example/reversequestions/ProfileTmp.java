package com.example.reversequestions;

public class ProfileTmp {

    public static String name = "";
    public static int score = 0;
    public static String id;
    public static int time;
    public static int avatar = 0;
    public static int currentExp = 0;
    public static int lvl = 0;
    public static int nextExp = 100;

    public static void setName(String name) {
        ProfileTmp.name = name;
    }

    public static void setScore(int score) {
        ProfileTmp.score = score;
    }

    public static void setTime(int time) {
        ProfileTmp.time = time;
    }
}
