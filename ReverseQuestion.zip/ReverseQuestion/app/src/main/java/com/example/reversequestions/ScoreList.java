package com.example.reversequestions;

import java.util.ArrayList;

public class ScoreList {
    public static ArrayList<Score> scoreList = new ArrayList<Score>();
}
