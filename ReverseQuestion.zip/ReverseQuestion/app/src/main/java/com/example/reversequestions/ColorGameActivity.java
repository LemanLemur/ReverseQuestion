package com.example.reversequestions;

import android.app.Activity;

public class ColorGameActivity extends Activity {

}
